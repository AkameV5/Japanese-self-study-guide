package com.example.japanese_self_study_guide.kanji;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.japanese_self_study_guide.R;

import java.util.List;

public class KanjiExerciseGroupsActivity extends AppCompatActivity {

    private LinearLayout layoutGroups;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanji_exercise_groups);

        layoutGroups = findViewById(R.id.layoutKanjiGroups);

        List<ExerciseGroup> groups = GroupsProvider.getGroups();

        for (ExerciseGroup group : groups) {
            Button btn = new Button(this);
            btn.setText(group.getTitle());
            btn.setTextSize(18f);
            btn.setTypeface(null, Typeface.BOLD);
            btn.setAllCaps(false);
            btn.setPadding(20, 20, 20, 20);

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 0, 0, 14);

            btn.setBackgroundResource(R.drawable.group_button);
            btn.setTextColor(getColor(R.color.textDark));

            btn.setLayoutParams(params);

            btn.setOnClickListener(v -> openExercises(group));

            layoutGroups.addView(btn);
        }
    }

    private void openExercises(ExerciseGroup group) {
        Intent intent = new Intent(this, KanjiExercisesActivity.class);
        intent.putExtra("startId", group.getStartId());
        intent.putExtra("endId", group.getEndId());
        intent.putExtra("limit", group.getLimit());
        startActivity(intent);
    }
}
